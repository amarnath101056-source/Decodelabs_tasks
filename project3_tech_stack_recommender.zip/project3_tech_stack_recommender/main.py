"""
DecodeLabs AI Internship - Project 3
AI Recommendation Logic (Tech Stack Recommender)

Author : Amarnath
Batch  : 2026

Pipeline (IPO Framework from the slides):
  INPUT   -> User's skills (min. 3) + job-role dataset (raw_skills.csv style)
  PROCESS -> TF-IDF vectorization + Cosine Similarity scoring
  OUTPUT  -> Top-N ranked job role recommendations
"""

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# -------------------------------------------------
# STEP 1: Ingestion - Job Role Dataset
# (Stand-in for raw_skills.csv mentioned in the slides.
#  Each job role's required skills are the "item" text.)
# -------------------------------------------------
job_roles = {
    "Data Scientist": "Python SQL Machine Learning Data Analysis Statistics Pandas",
    "DevOps Engineer": "AWS Docker Kubernetes CI/CD Automation Linux Cloud",
    "Backend Developer": "Java Python SQL APIs Databases REST Spring",
    "Frontend Developer": "JavaScript React CSS HTML UI Design Web Design",
    "Cloud Architect": "AWS Azure Cloud Computing Automation Networking Security",
    "Machine Learning Engineer": "Python Machine Learning TensorFlow Neural Networks Deep Learning",
    "Data Analyst": "SQL Excel Data Analysis Statistics Visualization Python",
    "Full Stack Developer": "JavaScript Python React Node.js SQL APIs Web Design",
    "Cybersecurity Analyst": "Security Networking Linux Python Cryptography Firewalls",
    "Mobile App Developer": "Java Kotlin Swift Mobile UI Android iOS",
}

df_jobs = pd.DataFrame({
    "role": list(job_roles.keys()),
    "skills_text": list(job_roles.values())
})

print("=" * 60)
print("STEP 1: JOB ROLE DATASET")
print("=" * 60)
print(df_jobs.to_string(index=False))

# -------------------------------------------------
# STEP 2: Take user input (min. 3 skills/interests)
# -------------------------------------------------
user_skills = ["Python", "Cloud Computing", "Automation"]  # example input

print("\n" + "=" * 60)
print("STEP 2: USER INPUT")
print("=" * 60)
print(f"User skills entered: {user_skills}")

user_profile_text = " ".join(user_skills)

# -------------------------------------------------
# STEP 3: Vector Mapping - TF-IDF
# (User profile + job roles must share the same vocabulary,
#  so we fit the vectorizer on job roles + user text together.)
# -------------------------------------------------
corpus = df_jobs["skills_text"].tolist() + [user_profile_text]

vectorizer = TfidfVectorizer()
tfidf_matrix = vectorizer.fit_transform(corpus)

job_vectors = tfidf_matrix[:-1]     # all job role vectors
user_vector = tfidf_matrix[-1]      # last row = user profile vector

# -------------------------------------------------
# STEP 4: Scoring - Cosine Similarity
# -------------------------------------------------
similarity_scores = cosine_similarity(user_vector, job_vectors).flatten()
df_jobs["similarity_score"] = similarity_scores

# -------------------------------------------------
# STEP 5: Sorting - rank by descending similarity
# -------------------------------------------------
ranked = df_jobs.sort_values(by="similarity_score", ascending=False).reset_index(drop=True)

# -------------------------------------------------
# STEP 6: Filtering - Top-N output (prevents choice overload)
# -------------------------------------------------
TOP_N = 3
top_matches = ranked.head(TOP_N)

print("\n" + "=" * 60)
print(f"STEP 6: TOP {TOP_N} RECOMMENDED CAREER PATHS")
print("=" * 60)
for i, row in top_matches.iterrows():
    print(f"{i + 1}. {row['role']:<25} | Match Score: {row['similarity_score'] * 100:.2f}%")

# -------------------------------------------------
# BONUS: Handling the Cold Start problem
# -------------------------------------------------
print("\n" + "=" * 60)
print("BONUS: COLD START CHECK")
print("=" * 60)
if similarity_scores.max() == 0:
    print("No matching skills found. Falling back to trending/popular roles:")
    print(df_jobs["role"].head(3).to_string(index=False))
else:
    print("User profile matched successfully - no cold start issue.")


def recommend(skills: list, top_n: int = 3) -> pd.DataFrame:
    """
    Reusable function: pass a list of skills, get back the
    top_n recommended job roles with similarity scores.
    """
    profile_text = " ".join(skills)
    local_corpus = df_jobs["skills_text"].tolist() + [profile_text]
    local_matrix = vectorizer.transform(local_corpus)
    job_vecs = local_matrix[:-1]
    user_vec = local_matrix[-1]
    scores = cosine_similarity(user_vec, job_vecs).flatten()

    result = df_jobs[["role"]].copy()
    result["similarity_score"] = scores
    return result.sort_values(by="similarity_score", ascending=False).head(top_n).reset_index(drop=True)


# -------------------------------------------------
# Demo: try a different user profile
# -------------------------------------------------
print("\n" + "=" * 60)
print("DEMO: NEW USER PROFILE")
print("=" * 60)
new_user = ["JavaScript", "React", "Web Design"]
print(f"New user skills: {new_user}")
print(recommend(new_user).to_string(index=False))
