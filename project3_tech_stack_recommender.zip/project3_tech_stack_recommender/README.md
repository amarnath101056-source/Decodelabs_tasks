# Project 3 – AI Recommendation Logic (Tech Stack Recommender)

**DecodeLabs AI Internship | Batch 2026**
**Author:** Amarnath

## Goal
Build a content-based recommendation engine that maps a user's skills to
the most relevant job roles, using TF-IDF + Cosine Similarity.

## Setup (per the Intern's Survival Toolkit)

1. Install [VS Code](https://code.visualstudio.com) and [Git](https://git-scm.com) if you haven't already.
2. Open this folder in VS Code.
3. Open the terminal with `Ctrl + ~`.
4. Create a virtual environment (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate      # On Windows: venv\Scripts\activate
   ```
5. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
6. Run the project:
   ```bash
   python main.py
   ```

## What it does
- Ingests a job-role dataset (10 roles, each with a skills profile)
- Takes user input (3+ skills/interests)
- Maps user profile + job roles into shared TF-IDF vector space
- Scores similarity using Cosine Similarity (angle-based, robust to profile length)
- Sorts and filters to the Top-3 highest-matching roles
- Bonus: cold-start fallback check + reusable `recommend()` function for testing new skill sets

## Key Skills
Logic building, pattern matching, recommendation concepts

## VS Code Cheat Codes (from the toolkit)
| Shortcut | Action |
|---|---|
| `Ctrl + ~` | Open terminal instantly |
| `Ctrl + /` | Comment/uncomment lines |
| `Shift + Alt + F` | Auto-format code |
| `Ctrl + P` | Find any file instantly |
