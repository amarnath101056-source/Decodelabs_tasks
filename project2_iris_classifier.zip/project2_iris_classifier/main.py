"""
DecodeLabs AI Internship - Project 2
Data Classification Using AI (Iris Dataset + KNN)

Pipeline (IPO Framework from the slides):
  INPUT   -> Load Iris dataset, scale features
  PROCESS -> Train-test split, KNN algorithm
  OUTPUT  -> Confusion matrix, F1 score, predictions
"""

import numpy as np
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import (
    confusion_matrix,
    classification_report,
    f1_score,
    accuracy_score,
)

# -------------------------------------------------
# STEP 1: Load and understand the dataset
# -------------------------------------------------
iris = load_iris()
X = iris.data                      # features: sepal/petal length & width
y = iris.target                    # labels: 0=setosa, 1=versicolor, 2=virginica
feature_names = iris.feature_names
target_names = iris.target_names

df = pd.DataFrame(X, columns=feature_names)
df["species"] = pd.Categorical.from_codes(y, target_names)

print("=" * 60)
print("STEP 1: DATASET OVERVIEW")
print("=" * 60)
print(f"Samples: {df.shape[0]}, Features: {len(feature_names)}, Classes: {len(target_names)}")
print(df.head())
print("\nClass distribution:\n", df["species"].value_counts())

# -------------------------------------------------
# STEP 2: Scale features (The Gatekeeper Rule)
# -------------------------------------------------
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# -------------------------------------------------
# STEP 3: Train-test split (shuffle to remove order bias)
# -------------------------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42, shuffle=True, stratify=y
)

print("\n" + "=" * 60)
print("STEP 3: TRAIN-TEST SPLIT")
print("=" * 60)
print(f"Training samples: {len(X_train)} | Testing samples: {len(X_test)}")

# -------------------------------------------------
# STEP 4: Apply KNN classification algorithm
# -------------------------------------------------
model = KNeighborsClassifier(n_neighbors=5)
model.fit(X_train, y_train)
predictions = model.predict(X_test)

# -------------------------------------------------
# STEP 5: Output validation
# -------------------------------------------------
print("\n" + "=" * 60)
print("STEP 5: OUTPUT VALIDATION")
print("=" * 60)

acc = accuracy_score(y_test, predictions)
f1 = f1_score(y_test, predictions, average="weighted")

print(f"Accuracy: {acc * 100:.2f}%")
print(f"F1 Score (weighted): {f1:.4f}")

print("\nConfusion Matrix:")
cm = confusion_matrix(y_test, predictions)
cm_df = pd.DataFrame(cm, index=target_names, columns=target_names)
print(cm_df)

print("\nClassification Report:")
print(classification_report(y_test, predictions, target_names=target_names))

# -------------------------------------------------
# STEP 6 (Bonus - suggested in slides): Tune K
# -------------------------------------------------
print("=" * 60)
print("BONUS: FINDING THE OPTIMAL K (The Elbow)")
print("=" * 60)
error_rates = []
k_values = range(1, 21)
for k in k_values:
    knn_k = KNeighborsClassifier(n_neighbors=k)
    knn_k.fit(X_train, y_train)
    pred_k = knn_k.predict(X_test)
    error_rates.append(np.mean(pred_k != y_test))

best_k = k_values[np.argmin(error_rates)]
print(f"Best K found: {best_k} (lowest error rate: {min(error_rates):.4f})")

# -------------------------------------------------
# STEP 7: Predict on a brand-new unseen sample
# -------------------------------------------------
print("\n" + "=" * 60)
print("BONUS: PREDICTING A NEW FLOWER SAMPLE")
print("=" * 60)
new_sample = np.array([[5.0, 3.4, 1.5, 0.2]])  # sepal_len, sepal_wid, petal_len, petal_wid
new_sample_scaled = scaler.transform(new_sample)
new_prediction = model.predict(new_sample_scaled)
print(f"New sample {new_sample.tolist()} -> Predicted species: {target_names[new_prediction[0]]}")
