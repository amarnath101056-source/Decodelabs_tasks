# Project 2 – Data Classification Using AI (Iris + KNN)

**DecodeLabs AI Internship | Batch 2026**
**Author:** Amarnath

## Goal
Build a basic classification model using a small dataset (Iris) with a
full supervised-learning pipeline: load → scale → split → train → validate.

## Setup (per the Intern's Survival Toolkit)

1. Install [VS Code](https://code.visualstudio.com) and [Git](https://git-scm.com) if you haven't already.
2. Open this folder in VS Code.
3. Open the terminal with `Ctrl + ~`.
4. Create a virtual environment (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate      # On Windows: venv\Scripts\activate
   ```
5. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
6. Run the project:
   ```bash
   python main.py
   ```

## What it does
- Loads the Iris dataset (150 samples, 3 classes, 4 features)
- Scales features with `StandardScaler`
- Splits into train/test sets (80/20, stratified, shuffled)
- Trains a `KNeighborsClassifier` (k=5)
- Evaluates with accuracy, F1 score, confusion matrix, and classification report
- Bonus: finds the optimal K via the elbow method, and predicts a brand-new sample

## Key Skills
Data handling, supervised learning basics, model training

## VS Code Cheat Codes (from the toolkit)
| Shortcut | Action |
|---|---|
| `Ctrl + ~` | Open terminal instantly |
| `Ctrl + /` | Comment/uncomment lines |
| `Shift + Alt + F` | Auto-format code |
| `Ctrl + P` | Find any file instantly |
