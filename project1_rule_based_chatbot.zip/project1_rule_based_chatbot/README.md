# Project 1 – Rule-Based Chatbot (DecoBot)

**DecodeLabs AI Internship | Batch 2026**
**Author:** Amarnath

## Goal
Build a rule-based chatbot that responds to predefined user inputs using
pure logic (dictionary lookup) — no machine learning involved.

## Setup (per the Intern's Survival Toolkit)

1. Install [VS Code](https://code.visualstudio.com) and [Git](https://git-scm.com) if you haven't already.
2. Open this folder in VS Code.
3. Open the terminal with `Ctrl + ~`.
4. No external dependencies are required (pure Python standard library).
5. Run the project:
   ```bash
   python main.py
   ```

## What it does
- **Input & Sanitization**: lowercases and strips whitespace so `HELLO`, ` hello `, `hello` all match.
- **Process (Intent Matching)**: O(1) dictionary lookup (`RESPONSES.get()`) instead of a long if-elif ladder.
- **Output (Feedback Loop)**: runs in an infinite loop until an exit command (`exit`, `quit`, `bye`, `goodbye`) is typed.
- Covers greetings, identity questions, AI/ML/DL definitions, jokes, and farewells.
- Type `help` anytime to see example prompts.

## Key Skills
Logic building, dictionary-based lookup, input sanitization, control flow

## VS Code Cheat Codes (from the toolkit)
| Shortcut | Action |
|---|---|
| `Ctrl + ~` | Open terminal instantly |
| `Ctrl + /` | Comment/uncomment lines |
| `Shift + Alt + F` | Auto-format code |
| `Ctrl + P` | Find any file instantly |
