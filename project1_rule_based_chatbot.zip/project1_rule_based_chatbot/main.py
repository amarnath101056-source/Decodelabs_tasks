"""
DecodeLabs AI Internship - Project 1: Rule-Based Chatbot

Author : Amarnath
Batch  : 2026
"""

# ── KNOWLEDGE BASE (Dictionary - O(1) lookup, no if-elif ladder) ──
RESPONSES = {
    # Greetings
    "hello": "Hello! How can I assist you today?",
    "hi": "Hey there! What can I do for you?",
    "hey": "Hey! I'm DecoBot. Ask me anything.",

    # Identity
    "what is your name": "I'm DecoBot, your Rule-Based AI assistant built at DecodeLabs.",
    "who are you": "I'm DecoBot — an AI chatbot powered by pure logic, no hallucinations!",

    # Status
    "how are you": "I'm running at 100% efficiency. All systems operational!",
    "are you a robot": "Yes! I'm a deterministic logic engine — no randomness here.",

    # Capabilities
    "what can you do": "I can answer predefined questions, greet you, and have a basic conversation.",
    "help": "Try asking: 'hello', 'what is AI', 'what is your name', or 'joke'.",

    # AI Knowledge
    "what is ai": "AI (Artificial Intelligence) is the simulation of human intelligence by machines.",
    "what is machine learning": "Machine Learning is a subset of AI where systems learn from data instead of explicit rules.",
    "what is deep learning": "Deep Learning uses neural networks with many layers to learn patterns from large datasets.",
    "what is a chatbot": "A chatbot is a program that simulates conversation — like me!",

    # Fun / Personality
    "joke": "Why do programmers prefer dark mode? Because light attracts bugs! 🐛",
    "tell me a joke": "Why did the AI fail the exam? It kept trying to learn instead of cheat! 😄",
    "what is your purpose": "My purpose is to prove that even simple logic can simulate intelligence.",

    # Farewells (handled separately for clean exit, but also in dict as friendly aliases)
    "bye": "Goodbye! Keep building. 🚀",
    "goodbye": "See you later! Keep coding.",
    "see you": "Catch you on the next loop! 👋",

    # Default handled by .get() fallback below
}

EXIT_COMMANDS = {"exit", "quit", "bye", "goodbye"}


# ── PHASE 1 : INPUT & SANITIZATION ──
def sanitize(raw: str) -> str:
    """Lowercase + strip whitespace — handles 'HELLO', ' Hello ', 'hello' uniformly."""
    return raw.lower().strip()


# ── PHASE 2 : PROCESS (Intent Matching) ──
def get_response(clean_input: str) -> str:
    """O(1) dictionary lookup with fallback — the professional approach."""
    return RESPONSES.get(clean_input, "I don't understand that yet. Type 'help' for options.")


# ── PHASE 3 : OUTPUT (Feedback Loop / Infinite Loop) ──
def run_chatbot():
    print("=" * 55)
    print("  DecoBot — Rule-Based AI Chatbot | DecodeLabs 2026")
    print("  Type 'help' for options  |  Type 'exit' to quit")
    print("=" * 55)

    while True:                                    # ← The Heartbeat
        raw_input = input("\nYou: ")
        clean_input = sanitize(raw_input)          # ← Sanitization

        if not clean_input:                        # ignore empty enter
            continue

        if clean_input in EXIT_COMMANDS:            # ← Exit Strategy (Kill Command)
            print("DecoBot: Goodbye! See you in the next project. 🚀")
            break

        response = get_response(clean_input)        # ← Intent Matching
        print(f"DecoBot: {response}")               # ← Response Generation


# ── ENTRY POINT ──
if __name__ == "__main__":
    run_chatbot()
